import React, { useState, useCallback } from 'react';
import { InputForm } from './components/InputForm';
import { JobAlert } from './components/JobAlert';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { findITJobInBoe } from './services/geminiService';
import type { JobAnalysis } from './types';

const App: React.FC = () => {
  const [analysisResult, setAnalysisResult] = useState<JobAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    if (!process.env.API_KEY) {
        setError("La API Key de Gemini no está configurada. Por favor, asegúrate de que la variable de entorno API_KEY está definida.");
        setIsLoading(false);
        return;
    }

    try {
      const result = await findITJobInBoe();
      setAnalysisResult(result);
    } catch (e: any) {
      console.error("Error en la búsqueda en tiempo real:", e);
      setError(e.message || "Ocurrió un error al realizar la búsqueda de empleos. Inténtalo de nuevo.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 py-8 px-4 sm:px-6 lg:px-8 text-slate-100">
      <div className="max-w-3xl mx-auto">
        <header className="mb-10 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-cyan-300">
            Buscador en Tiempo Real de Empleos IT en el BOE
          </h1>
          <p className="mt-3 text-lg text-slate-300 max-w-xl mx-auto">
            Pulsa el botón para que nuestra IA realice una búsqueda en tiempo real (vía Google Search) de nuevas ofertas de empleo en informática en el BOE.
          </p>
        </header>

        <main>
          <InputForm
            onAnalyze={handleSubmit}
            isLoading={isLoading}
          />

          {isLoading && <LoadingSpinner />}
          {error && <ErrorMessage message={error} />}
          
          {analysisResult && (
            <div className="mt-8">
              <JobAlert analysis={analysisResult} />
            </div>
          )}
        </main>

        <footer className="mt-16 text-center text-sm text-slate-400">
          <p>&copy; {new Date().getFullYear()} Sistema de Alerta de Empleo IT. Creado con React y Gemini API.</p>
          <p className="mt-1">Este es un proyecto de demostración que utiliza búsqueda en tiempo real. Verifica siempre la información en las fuentes oficiales del BOE.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;