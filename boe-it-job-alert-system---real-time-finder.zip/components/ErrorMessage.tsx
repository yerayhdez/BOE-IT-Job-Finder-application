
import React from 'react';

interface ErrorMessageProps {
  message: string;
}

const ExclamationTriangleIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
        <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.519 13.007c1.155 2-0.289 4.5-2.599 4.5H4.483c-2.31 0-3.753-2.5-2.598-4.5L9.4 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clipRule="evenodd" />
    </svg>
);


export const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  return (
    <div className="bg-red-700/30 border border-red-500 text-red-100 px-4 py-3 rounded-xl relative shadow-lg my-6" role="alert">
      <div className="flex items-center">
        <ExclamationTriangleIcon className="h-6 w-6 text-red-300 mr-3" />
        <div>
          <strong className="font-bold text-red-200">Error:</strong>
          <span className="block sm:inline ml-1 text-red-200">{message}</span>
        </div>
      </div>
    </div>
  );
};
    