import React from 'react';
import type { JobAnalysis } from '../types';

interface JobAlertProps {
  analysis: JobAnalysis;
}

const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.06-1.06l-3.103 3.104-1.48-1.482a.75.75 0 1 0-1.06 1.061l2.011 2.01a.75.75 0 0 0 1.06 0l3.632-3.633Z" clipRule="evenodd" />
  </svg>
);

const XCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
    <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-1.72 6.97a.75.75 0 1 0-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 1 0 1.06 1.06L12 13.06l1.72 1.72a.75.75 0 1 0 1.06-1.06L13.06 12l1.72-1.72a.75.75 0 1 0-1.06-1.06L12 10.94l-1.72-1.72Z" clipRule="evenodd" />
  </svg>
);

const InformationCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className || "w-5 h-5"}>
        <path fillRule="evenodd" d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-7-4a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM9 9a.75.75 0 0 0 0 1.5h.253a.25.25 0 0 1 .244.304l-.459 2.066A1.75 1.75 0 0 0 10.747 15H11a.75.75 0 0 0 0-1.5h-.253a.25.25 0 0 1-.244-.304l.459-2.066A1.75 1.75 0 0 0 9.253 9H9Z" clipRule="evenodd" />
    </svg>
);

const ArrowTopRightOnSquareIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className || "w-5 h-5"}>
    <path fillRule="evenodd" d="M4.25 5.5a.75.75 0 0 0-.75.75v8.5c0 .414.336.75.75.75h8.5a.75.75 0 0 0 .75-.75v-4a.75.75 0 0 1 1.5 0v4A2.25 2.25 0 0 1 12.75 17h-8.5A2.25 2.25 0 0 1 2 14.75v-8.5A2.25 2.25 0 0 1 4.25 4h5a.75.75 0 0 1 0 1.5h-5Z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M6.194 12.753a.75.75 0 0 0 1.06.053L16.5 4.44v2.81a.75.75 0 0 0 1.5 0v-4.5a.75.75 0 0 0-.75-.75h-4.5a.75.75 0 0 0 0 1.5h2.553l-9.056 8.19a.75.75 0 0 0 .053 1.06Z" clipRule="evenodd" />
  </svg>
);

const ListBulletIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className || "w-5 h-5"}>
    <path fillRule="evenodd" d="M2 4.75A.75.75 0 0 1 2.75 4h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 4.75ZM2 10a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 10Zm0 5.25a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1-.75-.75Z" clipRule="evenodd" />
  </svg>
);


export const JobAlert: React.FC<JobAlertProps> = ({ analysis }) => {
  if (analysis.isITJob) {
    return (
      <div className="bg-emerald-700/30 border border-emerald-500 p-6 rounded-xl shadow-xl text-emerald-100">
        <div className="flex items-start">
          <CheckCircleIcon className="h-8 w-8 text-emerald-400 mr-4 flex-shrink-0 mt-1" />
          <div>
            <h2 className="text-2xl font-bold text-emerald-300">¡Alerta de Empleo Informático Encontrada!</h2>
            <p className="mt-1 text-emerald-200">La IA ha identificado la siguiente oferta de empleo en el BOE a través de una búsqueda en tiempo real.</p>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          {analysis.jobTitle && (
            <div>
              <h3 className="text-sm font-semibold text-emerald-300 uppercase tracking-wider">Puesto Ofertado:</h3>
              <p className="text-lg text-emerald-100">{analysis.jobTitle}</p>
            </div>
          )}
          {analysis.entity && (
            <div>
              <h3 className="text-sm font-semibold text-emerald-300 uppercase tracking-wider">Entidad Convocante:</h3>
              <p className="text-lg text-emerald-100">{analysis.entity}</p>
            </div>
          )}
          {analysis.summary && (
            <div>
              <h3 className="text-sm font-semibold text-emerald-300 uppercase tracking-wider">Resumen:</h3>
              <p className="text-emerald-200 leading-relaxed">{analysis.summary}</p>
            </div>
          )}
          {analysis.keywords && analysis.keywords.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-emerald-300 uppercase tracking-wider">Palabras Clave / Tecnologías:</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                {analysis.keywords.map((keyword, index) => (
                  <span key={index} className="px-3 py-1 text-xs font-medium bg-emerald-600/50 text-emerald-200 rounded-full">
                    {keyword}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {analysis.boeUrl && (
          <div className="mt-6 pt-4 border-t border-emerald-600/50">
            <a
              href={analysis.boeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center w-full sm:w-auto px-4 py-2.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-emerald-900 bg-emerald-400 hover:bg-emerald-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-emerald-700/30 focus:ring-emerald-500 transition-colors duration-150"
              aria-label="Ver publicación en el BOE"
            >
              <ArrowTopRightOnSquareIcon className="w-5 h-5 mr-2" />
              Ver Publicación en BOE
            </a>
          </div>
        )}
        
        {analysis.citations && analysis.citations.length > 0 && (
          <div className="mt-6 pt-4 border-t border-emerald-600/50">
            <h3 className="text-sm font-semibold text-emerald-300 uppercase tracking-wider flex items-center">
              <ListBulletIcon className="w-4 h-4 mr-2" />
              Fuentes Consultadas (vía Google Search):
            </h3>
            <ul className="mt-2 space-y-1 list-inside text-emerald-200">
              {analysis.citations.map((citation, index) => (
                <li key={index} className="text-xs">
                  <a 
                    href={citation.uri} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="hover:text-emerald-100 hover:underline"
                    title={citation.uri}
                  >
                    {citation.title || citation.uri}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}

         <div className="mt-6 pt-4 border-t border-emerald-600/50 text-xs text-emerald-300">
            <div className="flex items-center">
                <InformationCircleIcon className="h-4 w-4 mr-1.5 flex-shrink-0" />
                <span>Recuerda verificar siempre la información completa y oficial directamente en el BOE u otras fuentes primarias. Esta herramienta utiliza IA y búsqueda web.</span>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-sky-700/30 border border-sky-500 p-6 rounded-xl shadow-xl text-sky-100">
      <div className="flex items-start">
        <XCircleIcon className="h-8 w-8 text-sky-400 mr-4 flex-shrink-0 mt-1" />
        <div>
          <h2 className="text-2xl font-bold text-sky-300">No se Encontró Oferta de Empleo IT</h2>
          {analysis.reason ? (
            <p className="mt-1 text-sky-200">{analysis.reason}</p>
          ) : (
            <p className="mt-1 text-sky-200">En la búsqueda en tiempo real, la IA no ha identificado una nueva oferta de empleo en el sector de la informática en el BOE.</p>
          )}
           {analysis.citations && analysis.citations.length > 0 && (
            <div className="mt-4 pt-3 border-t border-sky-600/50">
              <h3 className="text-xs font-semibold text-sky-300 uppercase tracking-wider flex items-center">
                <ListBulletIcon className="w-3 h-3 mr-1.5" />
                Fuentes Consultadas (vía Google Search):
              </h3>
              <ul className="mt-1.5 space-y-1 list-inside text-sky-200">
                {analysis.citations.map((citation, index) => (
                  <li key={index} className="text-xs">
                    <a 
                      href={citation.uri} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="hover:text-sky-100 hover:underline"
                      title={citation.uri}
                    >
                      {citation.title || citation.uri}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};