import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { JobAnalysis, GeminResponseJson, Citation } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY no está definida en las variables de entorno. El servicio Gemini no funcionará.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const findITJobInBoe = async (): Promise<JobAnalysis> => {
  if (!API_KEY) {
    throw new Error("La API Key de Gemini no está configurada. Por favor, configura la variable de entorno API_KEY.");
  }

  let jsonStr: string = ""; 

  const prompt = `
Actúa como un asistente experto que utiliza Google Search para encontrar ofertas de empleo recientes en el sector de la informática publicadas en el Boletín Oficial del Estado (BOE) de España.
Tu tarea es realizar una búsqueda, analizar los resultados y generar UNA (1) respuesta en formato JSON.

Considera consultas de búsqueda como: "ofertas empleo informatica BOE", "convocatoria oposiciones informatico BOE reciente", "empleo publico tecnologia BOE".

Si encuentras una o más ofertas de empleo IT relevantes y recientes en el BOE a través de Google Search:
Extrae la información de LA MÁS RECIENTE O RELEVANTE de ellas y formatea la respuesta JSON así:
{
  "isITJob": true,
  "jobTitle": "El título del puesto tal como aparece en la oferta (ej: 'Ingeniero/a de Software', 'Analista Programador/a TIC', 'Técnico/a Especialista en Ciberseguridad')",
  "entity": "La entidad convocante (ej: 'Ministerio de Asuntos Económicos y Transformación Digital', 'Universidad Complutense de Madrid', 'Servicio Andaluz de Salud')",
  "summary": "Un breve resumen de la oferta extraído de los resultados de búsqueda (2-3 frases), destacando responsabilidades o tecnologías clave si es posible.",
  "keywords": ["palabraClaveRelevante1", "tecnologiaPrincipal", "requisitoDestacado"] (una lista de 3-5 palabras clave importantes y específicas de la oferta),
  "boeUrl": "La URL directa y REAL a la publicación oficial en el BOE o al detalle de la convocatoria encontrada en la búsqueda. Debe ser una URL funcional.",
  "reason": null
}

Si, tras la búsqueda, NO encuentras ninguna oferta de empleo IT relevante y reciente en el BOE, o los resultados no son concluyentes:
La respuesta JSON debe ser:
{
  "isITJob": false,
  "jobTitle": null,
  "entity": null,
  "summary": null,
  "keywords": [],
  "boeUrl": null,
  "reason": "Una breve explicación de por qué no se encontró una oferta de empleo IT (ej: 'Tras la búsqueda en tiempo real, no se identificaron nuevas convocatorias para perfiles tecnológicos en el BOE.', 'Los resultados de búsqueda actuales no muestran ofertas de empleo IT activas en el BOE.', 'No se detectaron ofertas IT que cumplan los criterios en la búsqueda realizada.')"
}

Asegúrate de que tu respuesta sea únicamente el objeto JSON válido. No incluyas explicaciones fuera del JSON.
Prioriza la información más actual y relevante. Si encuentras múltiples ofertas, selecciona una para el informe.
La 'boeUrl' debe ser la URL directa al recurso oficial si es posible.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17", // Model compatible with tools
        contents: [{role: "user", parts: [{text: prompt}]}],
        config: {
            tools: [{googleSearch: {}}], // Enable Google Search tool
            temperature: 0.5, // Slightly lower temperature for more factual extraction
        },
    });

    jsonStr = response.text.trim(); 
    
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr) as GeminResponseJson;
    
    let citations: Citation[] | null = null;
    if (response.candidates && response.candidates[0] && response.candidates[0].groundingMetadata && response.candidates[0].groundingMetadata.groundingChunks) {
        citations = response.candidates[0].groundingMetadata.groundingChunks
            .filter(chunk => chunk.web && chunk.web.uri && chunk.web.title)
            .map(chunk => ({
                uri: chunk.web.uri!,
                title: chunk.web.title!,
            }));
    }


    return {
      isITJob: parsedData.isITJob,
      jobTitle: parsedData.jobTitle || null,
      entity: parsedData.entity || null,
      summary: parsedData.summary || null,
      keywords: parsedData.keywords || [],
      reason: parsedData.reason || null,
      boeUrl: parsedData.boeUrl || null,
      citations: citations,
    };

  } catch (error: any) {
    console.error("Error calling Gemini API or parsing response:", error);
    if (error.message && error.message.includes("API key not valid")) {
        throw new Error("La API Key de Gemini no es válida. Verifica que esté configurada correctamente.");
    }
    if (error.message && error.message.toLowerCase().includes("quota")) {
        throw new Error("Se ha excedido la cuota de la API de Gemini. Inténtalo más tarde.");
    }
     if (error.message && error.message.toLowerCase().includes("candidate was blocked due to safety")) {
        throw new Error("La respuesta fue bloqueada por motivos de seguridad. Intenta una búsqueda diferente o revisa el contenido.");
    }
    if (error instanceof SyntaxError) {
        throw new Error("La respuesta de la IA no tuvo un formato JSON válido. La IA devolvió: " + jsonStr );
    }
    throw new Error(`Error al procesar la solicitud con Gemini: ${error.message || 'Error desconocido'}`);
  }
};