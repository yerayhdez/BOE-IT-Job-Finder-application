export interface Citation {
  uri: string;
  title: string;
}

export interface JobAnalysis {
  isITJob: boolean;
  jobTitle: string | null;
  entity: string | null;
  summary: string | null;
  keywords: string[] | null;
  reason: string | null;
  boeUrl: string | null;
  citations: Citation[] | null;
}

export interface GeminResponseJson {
  isITJob: boolean;
  jobTitle?: string;
  entity?: string;
  summary?: string;
  keywords?: string[];
  reason?: string;
  boeUrl?: string; // This will now be a real URL if found
}